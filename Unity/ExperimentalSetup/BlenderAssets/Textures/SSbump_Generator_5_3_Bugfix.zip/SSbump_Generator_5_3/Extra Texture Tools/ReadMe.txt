These texture tools will eventually be a part of the main program.

To use specify ONE file from the command line, create a bat file, or drag and drop ONE texture onto the .exe or a shortcut to the .exe. 

Normal2DuDv will convert a normal map to a DuDv map.

Normal2Specular will generate a base specular map from a normal map. It will most likely need to be edited afterward.

Both these .exe files accept no command line parameters.

Neither of these .exe files need to be in the same folder as the textures you are working with.

These also fall under the terms of the GPLv3.