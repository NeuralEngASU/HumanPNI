function v=matleap_version
% MATLEAP_VERSION Get matleap version information
v=matleap(0);
